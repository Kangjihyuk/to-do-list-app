const todo = document.querySelector('#todo')
const add = document.querySelector('.btn')
add.addEventListener('click', function(){
  const newItem = document.createElement('li')
  const text = todo.value
  newItem.append(text)

  const button = document.createElement('button')
  button.innerHTML = 'Delete'
  newItem.appendChild(button)
  
  button.addEventListener('click',()=>{
    newItem.remove()
  })

  const letak = document.querySelector('ul')
  letak.insertBefore(newItem, letak.firstChild)
})

const btn2 = document.querySelector('.btn2')
btn2.addEventListener('click' ,() => {
  const item = document.querySelectorAll('li')
  item.forEach(items => items.remove())
})

